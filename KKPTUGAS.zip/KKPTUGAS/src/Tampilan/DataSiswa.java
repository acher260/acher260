/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tampilan;

import MyConnection.MyConnection;
import static Tampilan.DataKaryawan.tabel_kar;
import static Tampilan.DataKaryawan.txtagama;
import static Tampilan.DataKaryawan.txtid;
import static Tampilan.DataKaryawan.txtjabatan1;
import static Tampilan.DataKaryawan.txtjk;
import static Tampilan.DataKaryawan.txtnama;
import static Tampilan.DataKaryawan.txtnik;
import static Tampilan.DataKaryawan.txtnp;
import static Tampilan.DataKaryawan.txtpendidikan_ter1;
import static Tampilan.DataKaryawan.txttempatlahir;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author AHMAD FAUZI
 */
public class DataSiswa extends javax.swing.JFrame {
Connection conn;
        PreparedStatement ps;
        ResultSet rs;
    private DefaultTableModel tabmode;
    /**
     * Creates new form DataSiswa
     */
    public DataSiswa() {
        initComponents();
         Connect();
         Nis();
         Nisn();
         tahun();
         cetak();
    }

    
     public void Connect(){
        try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost/kkp_yaperjasa", "root", "");
    }catch (ClassNotFoundException ex) {
        Logger.getLogger(FormAbsenADM.class.getName()).log(Level.SEVERE, null, ex);
    }catch (SQLException ex){
        Logger.getLogger(FormAbsenADM.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
     
     public void cetak(){
     try{
            String file = "C:\\Users\\AHMAD FAUZI\\Documents\\NetBeansProjects\\KKPTUGAS\\src\\report\\LapDataSiswa.jrxml";
            JasperReport jr = JasperCompileManager.compileReport(file);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, MyConnection.getConnection());
            JasperViewer.viewReport(jp);
        } catch (Exception e){
        }
     }
        
     private void Nis() {
        try{
            String sql = "Select max(right(nis,2)) AS no FROM siswa";
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while (rs.next()){
                if (rs.first() == false){
                    txtnis.setText("3001");
                }else   {
                    rs.last();
                    int set_nis = rs.getInt(1) + 1;
                    String no = String.valueOf(set_nis);
                    int noLong = no.length();
                    for (int a = 0; a<3-noLong; a++){
                        no = "0" + no;
                    }
                    txtnis.setText("3" + no);
                }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: \n" + e.toString(), "Kesalahan", JOptionPane.WARNING_MESSAGE);
        }
    }
         
         
       private void Nisn() {
        try{
            String sql = "Select max(right(nisn,2)) AS no FROM siswa";
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while (rs.next()){
                if (rs.first() == false){
                    txtnisn.setText("0007686401");
                }else   {
                    rs.last();
                    int set_nisn = rs.getInt(1) + 1;
                    String no = String.valueOf(set_nisn);
                    int noLong = no.length();
                    for (int a = 0; a<3-noLong; a++){
                        no = "0" + no;
                    }
                    txtnisn.setText("00076864" + no);
                }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: \n" + e.toString(), "Kesalahan", JOptionPane.WARNING_MESSAGE);
        }
    }   
         
       public void tahun()
    {
        Calendar kal = new GregorianCalendar();
        int tahun = kal.get(Calendar.YEAR);
            String TAHUN = ""+tahun;
        txttahun.setText(TAHUN);
    }
         
       protected void aktif(){
        txtnama.setEnabled(true);
        txtnis.setEnabled(true);
        txtnisn.setEnabled(true);
        txtasal_sekolah.setEnabled(true);
        txtjk.setEnabled(true);
        txttempat_tgllahir.setEnabled(true);
        txttahun.setEnabled(true);
        txtnotelp.setEnabled(true);
        txtnama_ortu.setEnabled(true);
        txtalamat.setEnabled(true);
        txtnama.requestFocus();
    }  
       
       
       protected void kosong(){
        txtnama.setText("");
         txtjurusan.setSelectedIndex(0);
         txtasal_sekolah.setText("");
          txtjk.setText("");
           txttempat_tgllahir.setText("");
           txtagama.setSelectedIndex(0);
           txtnotelp.setText("");
           txtnama_ortu.setText("");
           txtalamat.setText("");
    }
       
        private void datatable(){
Object[] Baris ={"Nama Siswa", "Nis", "Nisn", "Jurusan Dipilih" ,"Asal Sekolah", "Jenis Kelamin", "Tempat & Tanggal Lahir", "Tahun Ajaran", "Agama", "Nomor Telepon", "Nama Orang Tua", "Alamat"};
tabmode = new DefaultTableModel(null, Baris);
tabel.setModel(tabmode);
String sql = "select * from siswa";
try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("nama_siswa");
                String b = hasil.getString("nis");
                String c = hasil.getString("nisn");
                String d = hasil.getString("jurusan");
                String e = hasil.getString("asal_sekolah");
                String f = hasil.getString("jenis_kelamin");
                String g = hasil.getString("tanggal_lahir");
                String h = hasil.getString("tahun_ajaran");
                String i = hasil.getString("agama");
                String j = hasil.getString("notelp");
                String k = hasil.getString("nama_ortu");
                String l = hasil.getString("alamat");
                String[] data={a,b,c,d,e,f,g,h,i,j,k,l};
                tabmode.addRow(data);
            }
        } catch (Exception e){
        }
    }
       
       
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        txtnisn = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtasal_sekolah = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtjk = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        txttahun = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtnotelp = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtnama_ortu = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtalamat = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtnis = new javax.swing.JTextField();
        txtagama = new javax.swing.JComboBox<>();
        txttempat_tgllahir = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        txtjurusan = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("DATA SISWA BARU");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 13, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel2.setText("Nama Siswa Baru");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 49, -1, -1));
        getContentPane().add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 47, 260, -1));

        txtnisn.setEditable(false);
        getContentPane().add(txtnisn, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 114, 260, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel3.setText("Nisn");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 107, -1, -1));
        getContentPane().add(txtasal_sekolah, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 184, 260, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel4.setText("Jurusan Dipilih");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 148, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel5.setText("Jenis Kelamin");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 227, -1, -1));
        getContentPane().add(txtjk, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 225, 120, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel6.setText("Tempat & Tanggal Lahir");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 262, -1, -1));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Siswa", "Nis", "Nisn", "Jurusan Dipilih", "Asal Sekolah", "Jenis Kelamin", "Tempat & Tanggal Lahir", "Tahun Ajaran", "Agama", "Nomor Telepon", "Nama Orang Tua", "Alamat"
            }
        ));
        tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 295, 980, 233));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel7.setText("Tahun Ajaran");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 49, -1, -1));

        txttahun.setEditable(false);
        getContentPane().add(txttahun, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 47, 60, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel8.setText("Agama");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 89, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel9.setText("Nomor Telepon");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 120, -1, -1));
        getContentPane().add(txtnotelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 118, 113, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel10.setText("Nama Orang Tua/Wali");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 157, -1, -1));
        getContentPane().add(txtnama_ortu, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 147, 250, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel11.setText("Alamat");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(483, 186, -1, -1));
        getContentPane().add(txtalamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 182, 250, 33));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel12.setText("Nis");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 75, -1, -1));

        txtnis.setEditable(false);
        txtnis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnisActionPerformed(evt);
            }
        });
        getContentPane().add(txtnis, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 82, 260, -1));

        txtagama.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txtagama.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Islam", "Hindu", "Budha", "Kristen", "Protestan", " " }));
        getContentPane().add(txtagama, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 84, 113, -1));
        getContentPane().add(txttempat_tgllahir, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 260, 212, -1));

        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton8.setText("TAMBAH");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(248, 558, -1, -1));

        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton9.setText("EDIT");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(348, 558, -1, -1));

        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton10.setText("HAPUS");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(428, 558, -1, -1));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton11.setText("CLEAR");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(518, 558, -1, -1));

        jButton13.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton13.setText("KEMBALI");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 560, 90, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        jLabel13.setText("Asal Sekolah");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 186, -1, -1));

        txtjurusan.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        txtjurusan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Jurusan", "AKUNTANSI", "ADM.PERKANTORAN" }));
        txtjurusan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtjurusanActionPerformed(evt);
            }
        });
        getContentPane().add(txtjurusan, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 147, 116, -1));

        jButton3.setBackground(new java.awt.Color(0, 0, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pic/IconRefresh.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 250, 52, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setText("Print");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 250, 80, 40));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pic/bgDATA SISWA.png"))); // NOI18N
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1020, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtnisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnisActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        String sql = "insert into siswa values(?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtnama.getText());
            ps.setString(2, txtnis.getText());
            ps.setString(3, txtnisn.getText());
            ps.setString(4, txtjurusan.getSelectedItem().toString());
            ps.setString(5, txtasal_sekolah.getText());
            ps.setString(6, txtjk.getText());
            ps.setString(7, txttempat_tgllahir.getText());
            ps.setString(8, txttahun.getText());
            ps.setString(9, txtagama.getSelectedItem().toString());
            ps.setString(10, txtnotelp.getText());
            ps.setString(11, txtnama_ortu.getText());
            ps.setString(12, txtalamat.getText());

            ps.execute();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            kosong();
            tahun();
            Nis();
            Nisn();
            datatable();
            txtnama.requestFocus();
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data gagal Disimpan"+e);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        try {
            String sql = "update siswa set nama_siswa=?, nisn=?, jurusan=?, asal_sekolah=?, jenis_kelamin=?, tanggal_lahir=?, tahun_ajaran=?, agama=?, notelp=?, nama_ortu=?, alamat=? where nis=?";
            PreparedStatement ps = conn.prepareStatement(sql); // TODO add your handling code here:
            ps.setString(1, txtnama.getText());
            ps.setString(2, txtnisn.getText());
            ps.setString(3, txtjurusan.getSelectedItem().toString());
            ps.setString(4, txtasal_sekolah.getText());
            ps.setString(5, txtjk.getText());
            ps.setString(6, txttempat_tgllahir.getText());
            ps.setString(7, txttahun.getText());
            ps.setString(8, txtagama.getSelectedItem().toString());
            ps.setString(9, txtnotelp.getText());
            ps.setString(10, txtnama_ortu.getText());
            ps.setString(11, txtalamat.getText());
            ps.setString(12, txtnis.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil DiEdit");
            kosong();
            Nis();
            Nisn();
            txtnama.requestFocus();
            datatable();
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal DiEdit"+e);
        }            // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        int ok = JOptionPane.showConfirmDialog(null, "Hapus","Konfirm Dialog", JOptionPane.YES_NO_CANCEL_OPTION);
        if (ok==0){
            String sql ="delete from siswa where nama_siswa ='"+txtnama.getText()+"'";
            try {
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
                kosong();
                txtnama.requestFocus();
                datatable();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus" +e);
            }
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        kosong();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        MenuAdmin u = new MenuAdmin();
        u.setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMouseClicked
int selectedRowIndex = tabel.getSelectedRow();
   TableModel model = tabel.getModel();
    String a = tabmode.getValueAt(selectedRowIndex, 0).toString();
    String b = tabmode.getValueAt(selectedRowIndex, 1).toString();
    String c = tabmode.getValueAt(selectedRowIndex, 2).toString();
    String d = tabmode.getValueAt(selectedRowIndex, 3).toString();
    String e = tabmode.getValueAt(selectedRowIndex, 4).toString();
    String f = tabmode.getValueAt(selectedRowIndex, 5).toString();
    String g = tabmode.getValueAt(selectedRowIndex, 6).toString();
    String h = tabmode.getValueAt(selectedRowIndex, 7).toString();
    String i = tabmode.getValueAt(selectedRowIndex, 8).toString();
    String j = tabmode.getValueAt(selectedRowIndex, 9).toString();
    String k = tabmode.getValueAt(selectedRowIndex, 10).toString();
    String l = tabmode.getValueAt(selectedRowIndex, 11).toString();
   
    txtnama.setText(a);
    txtnis.setText(b);
    txtnisn.setText(c);
    txtjurusan.setSelectedItem(d);
    txtasal_sekolah.setText(e);
    txtjk.setText(f);
    txttempat_tgllahir.setText(g);
    txttahun.setText(h);
    txtagama.setSelectedItem(i);
    txtnotelp.setText(j);
    txtnama_ortu.setText(k);
    txtalamat.setText(l);
            // TODO add your handling code here:
    }//GEN-LAST:event_tabelMouseClicked

    private void txtjurusanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtjurusanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtjurusanActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        datatable();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
try{
            String file = "CC:\\Users\\AHMAD FAUZI\\Documents\\NetBeansProjects\\KKPTUGAS\\src\\report\\LapDataSiswa.jrxml";
            JasperReport jr = JasperCompileManager.compileReport(file);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, MyConnection.getConnection());
            JasperViewer.viewReport(jp);
        } catch (Exception e){    
        }         // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DataSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DataSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DataSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DataSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataSiswa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabel;
    public static javax.swing.JComboBox<String> txtagama;
    private javax.swing.JTextField txtalamat;
    private javax.swing.JTextField txtasal_sekolah;
    private javax.swing.JTextField txtjk;
    private javax.swing.JComboBox<String> txtjurusan;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtnama_ortu;
    private javax.swing.JTextField txtnis;
    private javax.swing.JTextField txtnisn;
    private javax.swing.JTextField txtnotelp;
    private javax.swing.JTextField txttahun;
    private javax.swing.JTextField txttempat_tgllahir;
    // End of variables declaration//GEN-END:variables
}
