/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tampilan;
import MyConnection.MyConnection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
/**
 *
 * @author User
 */
public class FormAbsenADM extends javax.swing.JFrame {

    private DefaultTableModel tabmode;

    /**
     * Creates new form FormAbsenADM
     */
    public FormAbsenADM() {
        initComponents();        
        Connect();
        id_kar();
        hadir();
        tahun();
        aktif();
        kosong();
        datatable();

    }
         Connection conn;
        PreparedStatement ps;
        ResultSet rs;
        public void Connect(){
        try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost/kkp_yaperjasa", "root", "");
    }catch (ClassNotFoundException ex) {
        Logger.getLogger(FormAbsenADM.class.getName()).log(Level.SEVERE, null, ex);
    }catch (SQLException ex){
        Logger.getLogger(FormAbsenADM.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

        public void removeTable(){
    try{
         for(int t=tabmode.getRowCount();t>0;t--) {tabmode.removeRow(0);}    }
    catch(Exception ex){ System.out.println(ex);  } }
        
     protected void aktif(){
        txtid.setEnabled(true);
        txtnama.setEnabled(true);
        txtkodehadir.setEnabled(true);
        txttahun.setEnabled(true);
        txtid.requestFocus();
    }
    
    
    protected void kosong(){
        txtnama.setText("");
        txtjabatan.setSelectedIndex(0);
        txtbulan.setSelectedIndex(0);
        txtjammengajar.setSelectedIndex(0);
        txtjmlkehadiran.setSelectedIndex(0);
        txtsakit.setSelectedIndex(0);
        txtizin.setSelectedIndex(0);
        txttidakhadir.setSelectedIndex(0);
        txtcari.setText("");
        
    }   
     public void tahun()
    {
        Calendar kal = new GregorianCalendar();
        int tahun = kal.get(Calendar.YEAR);
            String TAHUN = ""+tahun;
        txttahun.setText(TAHUN);
    }    
     public void cetak(){
     try{
            String file = "C:\\Users\\AHMAD FAUZI\\Documents\\NetBeansProjects\\KKPTUGAS\\src\\report\\LapAbsenADM.jrxml";
            JasperReport jr = JasperCompileManager.compileReport(file);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, MyConnection.getConnection());
            JasperViewer.viewReport(jp);
        } catch (Exception e){
        }       
     }

     private void datatable(){
Object[] Baris ={"ID KARYAWAN", "NAMA KARYAWAN", "JABATAN", "KODE KARYAWAN", "BULAN", "TAHUN", "JUMLAH JAM MENGAJAR", "KEHADIRAN", "SAKIT", "IZIN","TIDAK HADIR"};
tabmode = new DefaultTableModel(null, Baris);
tabel.setModel(tabmode);
String sql = "select * from hadir";
try {
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id_kar");
                String b = hasil.getString("nama");
                String c = hasil.getString("jabatan");
                String d = hasil.getString("kode_kar");
                String e = hasil.getString("bulan");
                String f = hasil.getString("tahun");
                String g = hasil.getString("jumlah_jam");
                String h = hasil.getString("jumlah_kehadira");
                String i = hasil.getString("sakit");
                String j = hasil.getString("izin");
                String k = hasil.getString("tdk_hadir");
                String[] data={a,b,c,d,e,f,g,h,i,j,k};
                tabmode.addRow(data);
            }
        } catch (Exception e){
        }
    }
     
     private void id_kar()
    {
        try{
            String sql = "Select max(right(id_kar,2)) AS no FROM hadir";
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while (rs.next()){
                if (rs.first() == false){
                    txtid.setText("KAR-001");
                }else   {
                    rs.last();
                    int set_id = rs.getInt(1) + 1;
                    String no = String.valueOf(set_id);
                    int noLong = no.length();
                    for (int a = 0; a<3-noLong; a++){
                        no = "0" + no;
                    }
                    txtid.setText("KAR-" + no);
                }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: \n" + e.toString(), "Kesalahan", JOptionPane.WARNING_MESSAGE);
        }
    }
     
     
     private void hadir()
    {
        try{
            String sql = "Select max(right(kode_kar,2)) AS no FROM hadir";
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while (rs.next()){
                if (rs.first() == false){
                    txtkodehadir.setText("HADIR-001");
                }else   {
                    rs.last();
                    int set_hadir = rs.getInt(1) + 1;
                    String no = String.valueOf(set_hadir);
                    int noLong = no.length();
                    for (int a = 0; a<3-noLong; a++){
                        no = "0" + no;
                    }
                    txtkodehadir.setText("HADIR-" + no);
                }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: \n" + e.toString(), "Kesalahan", JOptionPane.WARNING_MESSAGE);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtjabatan = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        txtid = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtkodehadir = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtbulan = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        txttahun = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtjammengajar = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        txtjmlkehadiran = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        txtsakit = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        txtizin = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        txttidakhadir = new javax.swing.JComboBox<>();
        txtcari = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        cari = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jml = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        txtcetak = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 204, 204), null));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("DATA KARYAWAN");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel3.setText("ID KARYAWAN");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel9.setText("JABATAN");

        txtjabatan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Jabatan", "Kepala Sekolah", "Wakil Kepala Sekolah", "Staff TU", "Guru", "Keuangan", "Sekretaris", "Securty ", "Office Boy", "IT ", " " }));
        txtjabatan.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtjabatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtjabatanActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel10.setText("NAMA KARYAWAN");

        txtid.setEditable(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel10)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtnama, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(32, 32, 32)
                                .addComponent(txtid)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(txtjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel9)
                    .addComponent(txtjabatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 29, -1, 170));

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(204, 204, 204), null));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel11.setText("KODE KARYAWAN");

        txtkodehadir.setEditable(false);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel12.setText("TAHUN");

        txtbulan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "JANUARI", "FEBUARY", "MARET", "APRIL", "MEI ", "JUNI", "JULY", "AGUSTUS", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DESEMBER" }));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel13.setText("BULAN");

        txttahun.setEditable(false);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel12))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtkodehadir)
                            .addComponent(txtbulan, 0, 142, Short.MAX_VALUE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(txttahun, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtkodehadir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtbulan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txttahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, 170, 170));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel14.setText("JUMLAH JAM MENGAJAR");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 50, -1, -1));

        txtjammengajar.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txtjammengajar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8" }));
        txtjammengajar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtjammengajar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtjammengajarActionPerformed(evt);
            }
        });
        getContentPane().add(txtjammengajar, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 40, 50, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel15.setText("JUMLAH KEHADIRAN");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 80, -1, -1));

        txtjmlkehadiran.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txtjmlkehadiran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", " " }));
        txtjmlkehadiran.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtjmlkehadiran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtjmlkehadiranActionPerformed(evt);
            }
        });
        getContentPane().add(txtjmlkehadiran, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 70, 50, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel16.setText("SAKIT");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 110, -1, -1));

        txtsakit.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txtsakit.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        txtsakit.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        txtsakit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsakitActionPerformed(evt);
            }
        });
        getContentPane().add(txtsakit, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 100, 50, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel17.setText("IZIN");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, -1, -1));

        txtizin.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txtizin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        txtizin.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(txtizin, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 130, 50, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel18.setText("TIDAK HADIR");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 170, -1, -1));

        txttidakhadir.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        txttidakhadir.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        txttidakhadir.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(txttidakhadir, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 160, 50, -1));

        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });
        txtcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtcariKeyReleased(evt);
            }
        });
        getContentPane().add(txtcari, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 224, -1));

        jLabel19.setText("CARI DATA KARYAWAN MENURUT NAMA KARYAWAN");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, -1, -1));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID KARYAWAN", "NAMA KARYAWAN", "JABATAN", "KODE KARYAWAN", "BULAN", "TAHUN", "JUMLAH JAM MENGAJAR", "JUMLAH KEHADIRAN", "SAKIT", "IZIN", "TIDAK HADIR"
            }
        ));
        tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 307, 860, 162));

        cari.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        cari.setText("CARI");
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        getContentPane().add(cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 210, 69, -1));

        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton8.setText("TAMBAH");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, -1, -1));

        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton9.setText("EDIT");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, -1, -1));

        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton10.setText("HAPUS");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, -1, -1));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton11.setText("CLEAR");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, -1, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setText("DATA KEHADIRAN");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 6, -1, -1));

        jButton13.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        jButton13.setText("KEMBALI");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 260, -1, -1));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel1.setText("JUMLAH KARYAWAN :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, -1, -1));

        jml.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jml.setText("Karyawan");
        getContentPane().add(jml, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 210, -1, -1));

        jButton3.setBackground(new java.awt.Color(0, 0, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pic/IconRefresh.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 240, -1, -1));

        txtcetak.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        txtcetak.setText("CETAK");
        txtcetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcetakActionPerformed(evt);
            }
        });
        getContentPane().add(txtcetak, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 260, -1, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pic/bgabsenadm.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-6, 0, 890, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtjabatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtjabatanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtjabatanActionPerformed

    private void txtjammengajarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtjammengajarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtjammengajarActionPerformed

    private void txtjmlkehadiranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtjmlkehadiranActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtjmlkehadiranActionPerformed

    private void txtsakitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsakitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsakitActionPerformed

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcariActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        String sql = "insert into hadir values(?,?,?,?,?,?,?,?,?,?,?)";
    try {
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, txtid.getText());
        ps.setString(2, txtnama.getText());
        ps.setString(3, txtjabatan.getSelectedItem().toString());
        ps.setString(4, txtkodehadir.getText());
        ps.setString(5, txtbulan.getSelectedItem().toString());
        ps.setString(6, txttahun.getText());
        ps.setString(7, txtjammengajar.getSelectedItem().toString());
        ps.setString(8, txtjmlkehadiran.getSelectedItem().toString());
        ps.setString(9, txtsakit.getSelectedItem().toString());
        ps.setString(10, txtizin.getSelectedItem().toString());
        ps.setString(11, txttidakhadir.getSelectedItem().toString());
        
        ps.execute();
        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        kosong();
        tahun();
        id_kar();
        hadir();
        datatable();
        txtid.requestFocus();
    }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "Data gagal Disimpan"+e);
    }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMouseClicked
    int selectedRowIndex = tabel.getSelectedRow();
    String a = tabmode.getValueAt(selectedRowIndex, 0).toString();
    String b = tabmode.getValueAt(selectedRowIndex, 1).toString();
    String c = tabmode.getValueAt(selectedRowIndex, 2).toString();
    String d = tabmode.getValueAt(selectedRowIndex, 3).toString();
    String e = tabmode.getValueAt(selectedRowIndex, 4).toString();
    String f = tabmode.getValueAt(selectedRowIndex, 5).toString();
    String g = tabmode.getValueAt(selectedRowIndex, 6).toString();
    String h = tabmode.getValueAt(selectedRowIndex, 7).toString();
    String i = tabmode.getValueAt(selectedRowIndex, 8).toString();
    String j = tabmode.getValueAt(selectedRowIndex, 9).toString();
    String k = tabmode.getValueAt(selectedRowIndex, 10).toString();
    
    
    txtid.setText(a);
    txtnama.setText(b);
    txtjabatan.setSelectedItem(c);
    txtkodehadir.setText(d);
    txtbulan.setSelectedItem(e);
    txttahun.setText(f);
    txtjammengajar.setSelectedItem(g);
    txtjmlkehadiran.setSelectedItem(h);
    txtsakit.setSelectedItem(i);
    txtizin.setSelectedItem(j);
    txttidakhadir.setSelectedItem(k);
    
    
    }//GEN-LAST:event_tabelMouseClicked

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
    int ok = JOptionPane.showConfirmDialog(null, "Hapus","Konfirm Dialog", JOptionPane.YES_NO_CANCEL_OPTION);
        if (ok==0){
            String sql ="delete from hadir where id_kar ='"+txtid.getText()+"'";
            try {
                PreparedStatement stat = conn.prepareStatement(sql);
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
                kosong();
                txtid.requestFocus();
                datatable();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Data Gagal Dihapus" +e);
            }
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
    try {
        String sql = "update hadir set id_kar=?, jabatan=?, kode_kar=?, bulan=?, tahun=?, jumlah_jam=?, jumlah_kehadira=?, sakit=?, izin=?, tdk_hadir=? where  nama=?";
        PreparedStatement ps = conn.prepareStatement(sql); // TODO add your handling code here:
        ps.setString(1, txtid.getText());
        ps.setString(2, txtjabatan.getSelectedItem().toString());
        ps.setString(3, txtkodehadir.getText());
        ps.setString(4, txtbulan.getSelectedItem().toString());
        ps.setString(5, txttahun.getText());
        ps.setString(6, txtjammengajar.getSelectedItem().toString());
        ps.setString(7, txtjmlkehadiran.getSelectedItem().toString());
        ps.setString(8, txtsakit.getSelectedItem().toString());
        ps.setString(9, txtizin.getSelectedItem().toString());
        ps.setString(10, txttidakhadir.getSelectedItem().toString());
         ps.setString(11, txtnama.getText());
        
        
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Data Berhasil DiEdit");
        kosong();
        id_kar();
        hadir();
        txtid.requestFocus();
        datatable();
    }catch (SQLException e){
        JOptionPane.showMessageDialog(null, "Data Gagal DiEdit"+e);
        }            // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
    kosong();
    id_kar();
    hadir();
    datatable();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
     MenuAdmin u = new MenuAdmin();
            u.setVisible(true);
            this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
       String cari1= cari.getText();
    int jumdata=0;
    removeTable();
    String sql ="SELECT * FROM input_absensi_siswa where nis like '%"+cari1+"%' or nama like '%"+cari1+"%' or mk like '%"+cari1+"%'order by kelas asc";
    System.out.println(sql);

    try{
        java.sql.Statement stat = conn.createStatement();
        ResultSet hasil = stat.executeQuery(sql);
         while (hasil.next()){
            String a = hasil.getString("nis");
            String b = hasil.getString("nama");
            String c = hasil.getString("kelas");
            String d = hasil.getString("mapel");
            String e = hasil.getString("sakit");
            String f = hasil.getString("izin");
            String g = hasil.getString("tket");
            String h = hasil.getString("hadir");
            String data[]={a,b,c,d,e,f,g,h};
            tabmode.addRow(data);
            jumdata=jumdata+1;
            }

 }catch(SQLException sqle){
 jumdata=0;
 JOptionPane.showMessageDialog(null,"Data Gagal Masuk Tabel"+sqle);
 }
 jml.setText(jumdata+" Item");
              
    }//GEN-LAST:event_cariActionPerformed

    private void txtcariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtcariKeyReleased
        // TODO add your handling code here:
                String cari1= txtcari.getText();
    int jumdata=0;
    removeTable();
    String sql ="SELECT * FROM input_absensi_siswa where nis like '%"+cari1+"%' or nama like '%"+cari1+"%' order by nis asc";
    System.out.println(sql);

    try{
        java.sql.Statement stat = conn.createStatement();
        ResultSet hasil = stat.executeQuery(sql);
         while (hasil.next()){
           String a = hasil.getString("nis");
            String b = hasil.getString("nama");
            String c = hasil.getString("kelas");
            String d = hasil.getString("mapel");
            String e = hasil.getString("sakit");
            String f = hasil.getString("izin");
            String g = hasil.getString("tket");
            String h = hasil.getString("hadir");
            String data[]={a,b,c,d,e,f,g,h};
            tabmode.addRow(data);
            jumdata=jumdata+1;
            }

 }catch(SQLException sqle){
 jumdata=0;
 JOptionPane.showMessageDialog(null,"Data Gagal Masuk Tabel"+sqle);
 }
 jml.setText(jumdata+" Karyawan");
    }//GEN-LAST:event_txtcariKeyReleased

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        datatable();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtcetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcetakActionPerformed
        try{
            String file = "C:\\Users\\AHMAD FAUZI\\Documents\\NetBeansProjects\\KKPTUGAS\\src\\report\\LapAbsenADM.jrxml";
            JasperReport jr = JasperCompileManager.compileReport(file);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, MyConnection.getConnection());
            JasperViewer.viewReport(jp);

        } catch (Exception e){
        }
    }//GEN-LAST:event_txtcetakActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(FormAbsenADM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(FormAbsenADM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(FormAbsenADM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(FormAbsenADM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormAbsenADM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cari;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jml;
    private javax.swing.JTable tabel;
    private javax.swing.JComboBox<String> txtbulan;
    private javax.swing.JTextField txtcari;
    private javax.swing.JButton txtcetak;
    private javax.swing.JTextField txtid;
    private javax.swing.JComboBox<String> txtizin;
    private javax.swing.JComboBox<String> txtjabatan;
    private javax.swing.JComboBox<String> txtjammengajar;
    private javax.swing.JComboBox<String> txtjmlkehadiran;
    private javax.swing.JTextField txtkodehadir;
    private javax.swing.JTextField txtnama;
    private javax.swing.JComboBox<String> txtsakit;
    private javax.swing.JTextField txttahun;
    private javax.swing.JComboBox<String> txttidakhadir;
    // End of variables declaration//GEN-END:variables

}
